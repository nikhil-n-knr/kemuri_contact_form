import React, { useState } from 'react';
import './ContactForm.css'; // Optional custom styling

const ContactForm = () => {
  const [form, setForm] = useState({
    name: '',
    email: '',
    subject: 'contact_form',
    message: '',
    purpose: '',
    short_description: '',
    contacting_from: '',
    company_name: '',
  });

  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setSuccessMsg('');
    setErrorMsg('');

    try {
      const res = await fetch('http://127.0.0.1:8000/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify(form)
      });

      const result = await res.json();

      if (res.ok) {
        setSuccessMsg(result.message || 'Message sent successfully.');
        setForm({
          name: '',
          email: '',
          subject: 'contact_form',
          message: '',
          purpose: '',
          short_description: '',
          contacting_from: '',
          company_name: '',
        });

        setTimeout(() => setSuccessMsg(''), 10000);
      } else {
        throw result;
      }
    } catch (err) {
      setErrorMsg(err.message || 'Something went wrong');
      setTimeout(() => setErrorMsg(''), 10000);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {loading && (
        <div className="loader-overlay">
          <div className="spinner"></div>
        </div>
      )}

      <main className="contact-main">
        <form onSubmit={handleSubmit} className="contact-form">
          <h2>Contact Us</h2>

          <input
            type="text"
            name="name"
            placeholder="Name"
            required
            minLength={1}
            value={form.name}
            onChange={handleChange}
          />

          <input
            type="email"
            name="email"
            placeholder="Email"
            required
            value={form.email}
            onChange={handleChange}
          />

          <textarea
            name="message"
            placeholder="Message"
            rows="4"
            required
            value={form.message}
            onChange={handleChange}
          ></textarea>

          <select name="purpose" value={form.purpose} onChange={handleChange} required>
            <option value="">-- Select Purpose --</option>
            <option value="issue">Contacting to raise an issue in website content</option>
            <option value="connect">Contacting to get in touch with Kemuri</option>
          </select>

          {form.purpose === 'issue' && (
            <>
              <textarea
                name="short_description"
                placeholder="Short Description (optional)"
                rows="3"
                value={form.short_description}
                onChange={handleChange}
              ></textarea>

              <div className="radio-group">
                <label>
                  <input
                    type="radio"
                    name="contacting_from"
                    value="individual"
                    checked={form.contacting_from === 'individual'}
                    onChange={handleChange}
                    required
                  />
                  I am an individual
                </label>
                <label>
                  <input
                    type="radio"
                    name="contacting_from"
                    value="company"
                    checked={form.contacting_from === 'company'}
                    onChange={handleChange}
                    required
                  />
                  I am part of a company
                </label>
              </div>
            </>
          )}

          {form.contacting_from === 'company' && (
            <input
              type="text"
              name="company_name"
              placeholder="Company Name"
              value={form.company_name}
              onChange={handleChange}
              required
            />
          )}

          <button type="submit" disabled={loading}>
            {loading ? 'Sending...' : 'Send Message'}
          </button>

          {successMsg && <div className="success">{successMsg}</div>}
          {errorMsg && <div className="error">{errorMsg}</div>}
        </form>
      </main>
    </>
  );
};

export default ContactForm;